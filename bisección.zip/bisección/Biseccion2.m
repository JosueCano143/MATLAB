% M�todo de Bisecci�n

function [raiz, Xm, Iter] = Biseccion2(f,Xi,Xd,Tolerancia)
    Iter = 0;
    Xm = (Xi + Xd)/2;
    raiz = NaN; 
    if f(Xi)*f(Xd)<0
        while abs(f(Xm))>Tolerancia
            if f(Xi)*f(Xm)<0
                Xd=Xm;
            else
                Xi=Xm;
            end
            Iter = Iter + 1;
            Xm = (Xi + Xd)/2;
        end
        raiz = f(Xm);
    else
        disp('Error')
    end
end