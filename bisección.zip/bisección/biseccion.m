%Ejercicio de ejemplo

f = @(x) (-1/10)*x.^2+3;
%x = 10:0.1:10;
x = -2:0.1:10;
y = f(x);
Xi = -2;
Xd = 10;
Tolerancia = 10^-10;
[raiz,Xm,Iter]=Biseccion2(f,Xi,Xd,Tolerancia);
disp(['El valor de y es = ' num2str(raiz)])
disp(['El valor de Xm es = ' num2str(Xm)])
disp(['La cantidad de iteraciones es = ' num2str(Iter)])
%plot(x,y)
%grid on 


%% Programa 1

%Paso 1: graficaci�n de la ecuaci�n con funci�n an�nima
f = @(x) x-cos(x);
%x = -10:0.1:10; %Rango de -10 a 10 de 0.1 en 0.1

%Paso 2: definici�n de un nuevo rango
x = -2:0.1:2; %Rango de -2 a 2

%Paso 3: Obtenci�n de la ra�z de la funci�n 
y = f(x);
Xi = -2;
Xd = 2;
Tolerancia = 10^-20;
[raiz,Xm,Iter]=Biseccion2(f,Xi,Xd,Tolerancia);
disp(['El valor de y es = ' num2str(raiz)])
%Valor de x = 0.73909 (calculado con Xm)
disp(['El valor de Xm es = ' num2str(Xm)])
disp(['La cantidad de iteraciones es = ' num2str(Iter)])
%plot(x,y)
%grid on 

%% Programa 2

%Paso 1: graficaci�n de la ecuaci�n con funci�n an�nima
f = @(x) (x.^2).*sin(x);
%x = -10:0.1:10; %Rango de -10 a 10 de 0.1 en 0.1

%Paso 2: definici�n de un nuevo rango
x = -4:0.1:-1; %Rango de 2 a 4

%Paso 3: Obtenci�n de la ra�z de la funci�n 
y = f(x);
Xi = -4;
Xd = -1;
Tolerancia = 10^-20;
[raiz,Xm,Iter]=Biseccion2(f,Xi,Xd,Tolerancia);
disp(['El valor de y es = ' num2str(raiz)])
%Valor de x = 0 (calculado con Xm)
disp(['El valor de Xm es = ' num2str(Xm)])
disp(['La cantidad de iteraciones es = ' num2str(Iter)])
plot(x,y)
grid on 

%% Programa 3

%Paso 1: graficaci�n de la ecuaci�n con funci�n an�nima
f = @(x) x.*log(x);
%x = -10:0.1:10; %Rango de -10 a 10 de 0.1 en 0.1

%Paso 2: definici�n de un nuevo rango
x = 0.5:0.1:4; %Rango de -2 a 2

%Paso 3: Obtenci�n de la ra�z de la funci�n 
y = f(x);
Xi = 0.5;
Xd = 4;
Tolerancia = 10^-20;
[raiz,Xm,Iter]=Biseccion2(f,Xi,Xd,Tolerancia);
disp(['El valor de y es = ' num2str(raiz)])
%Valor de x = 1 (calculado con Xm)
disp(['El valor de Xm es = ' num2str(Xm)])
disp(['La cantidad de iteraciones es = ' num2str(Iter)])
%plot(x,y)
%grid on 

%% Programa 4

%Paso 1: graficaci�n de la ecuaci�n con funci�n an�nima
f = @(x) exp(0.3.*x)-x.^2;
%x = -10:0.1:10; %Rango de -10 a 10 de 0.1 en 0.1

%Paso 2: definici�n de un nuevo rango
x = 0:0.1:2; %Rango de 0 a 2

%Paso 3: Obtenci�n de la ra�z de la funci�n 
y = f(x);
Xi = 0;
Xd = 2;
Tolerancia = 10^-20;
[raiz,Xm,Iter]=Biseccion2(f,Xi,Xd,Tolerancia);
disp(['El valor de y es = ' num2str(raiz)])
%Valor de x = 1.1966 (calculado con Xm)
disp(['El valor de Xm es = ' num2str(Xm)])
disp(['La cantidad de iteraciones es = ' num2str(Iter)])
%plot(x,y)
%grid on 

%% Programa 5

%Paso 1: graficaci�n de la ecuaci�n con funci�n an�nima
f = @(x) 2*cos(x)-sqrt(x)/2;
%x = -10:0.1:10; %Rango de -10 a 10 de 0.1 en 0.1

%Paso 2: definici�n de un nuevo rango
x = 0.5:0.1:2; %Rango de -2 a 2

%Paso 3: Obtenci�n de la ra�z de la funci�n 
y = f(x);
Xi = 0.5;
Xd = 2;
Tolerancia = 10^-30;
[raiz,Xm,Iter]=Biseccion2(f,Xi,Xd,Tolerancia);
disp(['El valor de y es = ' num2str(raiz)])
%Valor de x = 1.2836 (calculado con Xm)
disp(['El valor de Xm es = ' num2str(Xm)])
disp(['La cantidad de iteraciones es = ' num2str(Iter)])
%plot(x,y)
%grid on 

